package CharacterDataBase;

import HashMap.HashedDictionary;
import Character.Character;

public class CharacterDatabase implements CharacterDataBaseInterface{

    private HashedDictionary<String, Integer> dictionary;

    public CharacterDatabase(){
        dictionary = new HashedDictionary<>();
    }

    @Override
    public void addCharacter(String name, int height, int weight, double moralAlign) {

        dictionary.add(name, height);
    }

    @Override
    public void removeCharacter(String name) {
        dictionary.remove(name);
    }

    @Override
    public Character getCharacter(String name) {
        return dictionary.getValue(name);
    }

    @Override
    public HashedDictionary<String, Integer> getHashTable() {
        return dictionary;
    }

    public void print(){
        dictionary.displayHashTable();
    }
}
