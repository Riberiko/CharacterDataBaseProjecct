import Character.Character;
import CharacterDataBase.CharacterDatabase;

public class Main {
    public static void main(String[] args) {
        CharacterDatabase temp = new CharacterDatabase();


        temp.addCharacter("Riko", 60,90,0);
        temp.addCharacter("Atha", 60,90,0);
        temp.addCharacter("Cesa", 60,90,0);
        temp.addCharacter("Fran", 60,90,0);

        temp.print();
    }
}
