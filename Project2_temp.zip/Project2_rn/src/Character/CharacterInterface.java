package Character;

public interface CharacterInterface {

    public void heal(int val);

    public void injure(int val);

    public void change(double percent);

    public void printCharacterSheet();
}
