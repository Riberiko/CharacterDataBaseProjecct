package Character;

import javax.swing.plaf.synth.SynthSpinnerUI;

public class Character implements CharacterInterface{

    private int health;
    private CharacterType type;
    private Integer id;

    private String name;    //Limit to 9 chars
    public int height;  //pixels
    private double weight; //kg

    private boolean onlineStatus;
    private double moralAlignment;

    public Character(String name){
        this(name, 64);
    }

    public Character(String name, int height){
        this(name, height, 10);
    }

    public Character(String name, int height, int weight){
        this(name, height, weight,0);
    }

    public Character(String name, int height, int weight, double moralAlignment){
        this(name, height, weight, moralAlignment, CharacterType.WARRIOR);
    }

    public Character(String name, int height, int weight, double moralAlignment, CharacterType type){
        this.name = name;
        this.height = height;
        this.weight = weight;
        this.moralAlignment = moralAlignment;
        this.type = type;
    }

    public void logIn(){
        onlineStatus = true;
    }

    public void logOut(){
        onlineStatus = false;
    }

    public void setName(String name){
        this.name = name;
    }

    public void setCharacterType(CharacterType type){
        this.type = type;
    }

    public void setHealth(int health){
        this.health = health;
    }

    public void heal(int addHealth){
        assert addHealth <= 100;
        setHealth(health+addHealth);
    }

    public void injure(int removeHealth){
        assert removeHealth <= 100;
        setHealth(health-removeHealth);
    }

    public void change(double percent){
        assert percent <= 100 || percent >= -100;
        moralAlignment = (percent/100);
    }

    public String getName(){
        return name;
    }

    public CharacterType getType(){
        return type;
    }

    public int getHealth(){
        return health;
    }

    public int getHeight() {
        return height;
    }

    public double getWeight(){
        return weight;
    }

    public void setHeight(int height){
        this.height = height;
    }

    public void setWeight(double weight){
        this.weight = weight;
    }

    public String toString(){
        return id +" "+ name +" "+ type +" "+ health +"\n";
    }

    public void printCharacterSheet(){
        System.out.println(toString());
    }



}
