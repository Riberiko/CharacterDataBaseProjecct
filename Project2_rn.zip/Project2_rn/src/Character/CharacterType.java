package Character;

public enum CharacterType {
    WARRIOR, ASSASSIN, MAGE, ARCHER, BERSERKER, SUMMONER;
}
